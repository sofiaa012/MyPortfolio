<?php 
//Sambungan ke DB
include ('db_conn.php');

//dapatkan id tempahan
$email = $_GET["email"];

###### jika user klik button KEMASKINI, ########
###### update record dalam jadual       ########

if(isset($_POST['edit']))
{
    //semak tarikh yang dimasukkan
    //jika tarikhmasuk Lebih besar

    $name = $_POST['name'];
    $phone = $_POST['nohp'];

    $sql = "UPDATE `user` SET `name` = '$name', `nohp` = '$phone' WHERE email = '$email'";
    //$sql = "UPDATE `booking` SET `flightid` = '$flight', `departing` = '$departing', `returning` = '$returning' WHERE `booking`.`id` = '$id'";

            if (mysqli_query($conn, $sql)) {
            echo '<script>alert("Booking Information Update Successful!");
                  window.location.href="admin_profile.php";
                  </script>';
            } else {
                echo "Error ; ". mysqli_error($conn); }
}
########## PROSES UPDATE TAMAT #################################

//dapatkan data tempahan dari jadual untuk display dalam textfield
$query = "SELECT * FROM user WHERE role = 1 AND email LIKE '$email'";

$result = mysqli_query($conn, $query) or die(mysql_error());
$row1 = mysqli_fetch_array($result);

?>
<html>
<head>
<style>
#mainbody
{
  background-color: white;
  padding: 20px;
  margin-left: 25%;
  margin-top: 5%;
}
#tajuk
{
    font-size: 30px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
    color: black;
}
table {
    border: 2px solid black;
    border-collapse: collapse;
    margin: auto;
    background-color: lightskyblue;
    color: black;
}
table, td {
    text-align: right;
}
</style>
</head>	

<body>
<?php
include ("sidebar.php");
?>
<div id="mainbody">
<form action="" method="POST">
    <div id="tajuk"><p><center>Admin Update Form</p></div>
<table cellpadding=5px>
<tr>
    <td style="width: 20px"></td>
    <td></td>
    <td></td>
    <td style="width: 20px"></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td align="right"></td>
    <td align="left">Email :</td>
    <td><input type="text" name="email"
               value="<?php echo $row1['email']; ?>" disabled>
        </td>
    <td></td>
</tr>

<tr>
    <td></td>
    <td>Name :</td>
    <td><input type="text" name="name"
               value="<?php echo $row1['name']; ?>" required>
        </td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>No. Telephone :</td>
    <td><input type="phone" name="nohp"
               value="<?php echo $row1['nohp']; ?>" required>
        </td>
<td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td><input type="submit" name="edit" value="EDIT"></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
</table>

</form>
</div>

</body>
</html>