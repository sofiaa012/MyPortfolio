<style>
 .footer-section a, .footer-logo{
 	color:#F3ECDC;
 }
 .footer-section {
  background: #344E41;
  color: #F3ECDC;
  margin: 0 auto; 
}
</style>
		<!-- Start Footer Section -->
		<footer class="footer-section" style="background:#344E41; color:#F3ECDC">
			<div class="container relative">

				<div class="row g-5 mb-5">
					<div class="col-lg-4">
						<div class="mb-4 footer-logo-wrap"><a href="index.php" class="footer-logo" style="color:#F3ECDC;">H O U S E<span>.</span></a></div>
						<p class="mb-4">Unlock your perfect homestay with our top-tier booking platform, where comfort meets convenience seamlessly.</p>

						<ul class="list-unstyled custom-social">
							<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
							<li><a href="#"><span class="fa fa-brands fa-pinterest"></span></a></li>
						</ul>
					</div>

					<div class="col-lg-8">

						<div class="row links-wrap">
							<div class="col-6 col-sm-6 col-md-4">
								<p><b>Quick Links</b></p>
								<ul class="list-unstyled">
									<li><a href="index.php">Home</a></li>
									<li><a href="house-list.php">House list</a></li> 
									<li><a href="contactus.php">Contact us</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-4">
								<p><b>Our Details</b></p>
								<ul class="list-unstyled">
									<li><a href="#"><span class="fa fa-globe"></span> Malaysia</a></li>
									<li><a href="#"><span class="fa fa-envelope"></span> sscottege@gmail.com</a></li>
									<li><a href="#"><span class="fa fa-phone"></span> 035502457</a></li>
								</ul>
							</div>

						</div>
					</div>

				</div>

				<div class="border-top copyright">
					<div class="row pt-12">
						<div class="col-lg-12 text-center" style="margin:0;>
							<center><p class="mb-2 text-center text-lg-start">All rights reserved &copy;2024 - SS Cottege </p></center>
						</div>

					</div>
				<!-- </div> -->

			</div>
		</footer>
		<!-- End Footer Section -->	