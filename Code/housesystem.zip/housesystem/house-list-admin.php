<?php

session_start();
require('db_connect.php');

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

$sessionemail = $_SESSION["email"];

		$query = "SELECT * FROM user where email = '$sessionemail'";
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
    $count = mysqli_num_rows($result);

    //fetch data from DB
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $nameDB = $row['name'];

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-admin.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>HOUSE LIST</h1>
							<p><a href="index-admin.php" class="btn btn-secondary me-2">Dashboard</a>&nbsp;&nbsp;<a href="booking-mgmt-admin.php" class="btn btn-white-outline">Booking</a>&nbsp;&nbsp;<a href="hmsty-cntrl-admin.php" class="btn btn-white-outline">Homestay</a></p>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->


		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">

		      		<?php
            		$query2 = "SELECT * FROM house";
	              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	              $count = mysqli_num_rows($result);

	                $a =1;

	              if($count>=1)
	              {

	                //fetch data from DB
	                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	                {
	                    $houseid = $row['houseid'];
	                    $housename = $row['housename'];
	                    $price = $row['price'];
	                    $nounit = $row['nounit'];

	                    $query3 = "SELECT * FROM img_house where houseid ='$houseid'";
				              $result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
				              $count3 = mysqli_num_rows($result3);
            	?>

							<!-- Start Column 2 -->
							<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
								<a class="product-item" href="#">
									<?php
											if($count3>=1)
											    {
						              
						              	$row3 = mysqli_fetch_array($result3,MYSQLI_ASSOC);
							                $file_name = $row3['file_name'];
							                $uploaded_on = $row3['uploaded_on'];
									?>
									<img src="uploads/<?php echo $file_name; ?>" WIDTH=100% class="img-fluid product-thumbnail" STYLE="width:100%">
									<?php 
														}else if($count3==0){ ?>

									
									<img src="uploads/none.jpg" class="img-fluid product-thumbnail">

									<?php 		} ?>
									<h3 class="product-title"><?php echo $housename. " (".$houseid.")";?></h3>


									<strong class="product-price"><?php echo "RM ".$price;?></strong>

								</a>
							</div> 
							<?php

							 			} 
							 		}
							?>
							<!-- End Column 2 -->

							<br><BR>
							
							<a href="booking-mgmt-admin.php" class="btn btn-secondary me-2">Booking Here</a>

		      

		      	</div>
		    </div>
		</div>


		<!-- Start Footer Section -->
			<?php include("footer-admin.php"); ?>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
