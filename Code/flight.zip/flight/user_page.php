<!DOCTYPE html>
<html>
<head>
	<?php include 'db_conn.php';
			session_start();?>
	<title>Flight Booking System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  	<link href="https://fonts.googleapis.com/css?family=Pacifico|Paytone+One" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<style type="text/css">
	#notis {
    font-size: 12px;
	font-weight: bold;
	color: white;
}
.team{
            position: relative;
            width: 100%;
            height: 700px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            margin-top: px;
        }
</style>

<body>

	<!--NavBar-->
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">
					<img src="logo.png" id="logo">FH AIRWAYS
				</a>
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expended="false">
					<span class="sr-only"> Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li class="active"><a href="user_page.php"><strong>Flights</strong></a></li>
					<li><a href="myBooking.php"><strong>My Booking</strong></a></li>
					<li><a href="flightinformation.php"><strong>Flight Information</strong></a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a><b>Hi, <?php echo $_SESSION['name']; ?></b></a></li>
					<li><a href="index.php"><i class="fa fa-sign-out"><strong>Logout</strong></i></a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!--NavBar End-->

<section class="team">

	<!--Tabs-->
	<div class="container" id="second">
		<!--Tabs Headings-->
		<ul class="nav nav-tabs">
			<li class="active"><a class="tabshead" data-toggle="tab" href="#home"><i class="fas fa-plane"></i>Flights</a></li>
		</ul>
		<!--Tabs Heading End-->

		<!--Tabs Content-->
		<div class="tab-content">
			<!--Tab Content Flight-->
			<div class="tab-pane fade in active" id="home">
        		<h3 class="lab">Flights</h3>
        		<form action="booking_process.php" method="POST">
        			<span class="lab">Flight:</span>
	         		<select name="flight" class="drop" id="ori" required>
	          			<option value="">- - -Choose- - -</option>
	          			<?php
				            $mysql = mysqli_query($conn,
				                     "SELECT * FROM flight ORDER BY flightname");
				            while ($row = mysqli_fetch_array($mysql))
				            {
			            ?>
				            <option value="<?php echo $row['flightid']; ?>">
				                     <?php echo $row['flightname']; ?></option>
			            <?php } ?>
	          		</select>
	          		<span class="lab">Passenger:</span>
			        <input type="number" class="drop" name="passenger" step="1" min="1" max="10" placeholder="Number Of Passengers" required>
			        <br>
			        <span class="lab">Departure:</span>
			        <input type="date" name="departing" class="drop" id="depart" required>
			        <span class="lab">Return:</span>
			        <input type="date" name="returning" class="drop" id="return" required>
			        <input type="submit" name="submit" value="BOOKING" id="flightsButton">
		        </form>
      		</div>
      		<!--Tab Content Flight End-->
      		</div>
    	</div>
    	<!--Tab Contents End-->
  	</div>
    <!--Tabs End-->
</section>
</body>
</html>
