<?php
session_start();
require('db_connect.php');

$houseid = $_GET['houseid'];
//$str2 = ltrim($houseid22, "%27");

ECHO $houseid;

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

   // File upload directory 
		$targetDir = "uploads/"; 

		if(isset($_POST["submit"])){ 

		  if(!empty($_FILES["file"]["name"])){ 
		      $fileName = basename($_FILES["file"]["name"]); 
		      $targetFilePath = $targetDir . $fileName; 
		      $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION); 
		   
		      // Allow certain file formats 
		      $allowTypes = array('jpg','png','jpeg','gif'); 
		      if(in_array($fileType, $allowTypes)){ 
		          // Upload file to server 
		          if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){ 
		              // Insert image file name into database 
		              $query8 = "INSERT INTO img_house (file_name, houseid) VALUES ('$fileName','$houseid')";
		              $insert2 =mysqli_query($connection, $query8);
		              if($insert2){ 
		                  echo '<script type ="text/JavaScript">alert("The house has been uploaded successfully.")</script>'; 
		              }else{ 
		                  echo '<script type ="text/JavaScript">alert("File upload failed, please try again.")</script>'; 
		              }  
		          }else{ 
		              echo '<script type ="text/JavaScript">alert("Sorry, there was an error uploading your file.")</script>'; 
		          } 
		      }else{ 
		        echo '<script type ="text/JavaScript">alert("Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.")</script>'; 
		      } 
		  }else{ 
		      echo '<script type ="text/JavaScript">alert("Please select a file to upload.")</script>';
		      
		  } 
		  header('Location: img-hmsty-admin.php?houseid='.$houseid);
		} 


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-admin.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero" style="height:60px;">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>HOMESTAY CONTROL</h1>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		<div class="product-section ">
		    <div class="container">
		      	<div class="row">

		      		<div class="col-lg-12">
		      			<div class="section-header">
				          <h2>Image House</h2>
				        </div>
				      </div>

            	<!-- Start Form -->
              <form method="post" action="img-hmsty-admin2.php" enctype="multipart/form-data">
               	<div class="form-group">
              		<label class="text-black">Upload House Image</label>
              		<input id="formFileLg" name="file" type="file" class="btn btn-primary" accept="image/*" required/>
              	</div>

                <br>

                <button type="submit" name="submit" class="btn btn-primary-hover-outline">Send</button>
              </form>


            	</div>

		      	</div><br><br>
		    </div>
		</div>



		<!-- Start Footer Section -->
			<?php include("footer-admin.php"); ?>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
