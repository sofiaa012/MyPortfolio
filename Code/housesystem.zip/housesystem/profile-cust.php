<?php

session_start();
require('db_connect.php');

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

  $emailuser = $_SESSION["email"];


		if(isset($_POST["submit-test"])){ 

		  $name = $_POST['name'];
		  $nohp = $_POST['nohp'];

	    $sql2 = "UPDATE user SET name = '$name', nohp = '$nohp' WHERE email = '$emailuser'";

			if ($connection->query($sql2) === TRUE) {
			    echo '<script type ="text/JavaScript">alert("Record updated Successfully")</script>';  
			} else {
			    echo "Error updating record: " . $connection->error;
			}

		 
		} 


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-cust.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<!-- <div class="hero" style="height:60px;">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>HOMESTAY CONTROL</h1>
						</div>
					</div>
				</div>
			</div> -->
		<!-- End Hero Section -->

		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">

		      		<div class="col-lg-12">
		      			<div class="section-header">
				          <h2>Customer Profile</h2>
				          <p>Customer Details</p>
				        </div>
				      </div>
      
				      <!-- Start Form -->

				      <?php
            		$query2 = "SELECT * FROM user where email='$emailuser'";
	              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	              $count = mysqli_num_rows($result);

	                $a =1;

	              if($count>=1)
	              {

	                //fetch data from DB
	                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	                {
	                    $email = $row['email'];
	                    $name = $row['name'];
	                    $nohp = $row['nohp'];
            	?>

              <form method="post" action="profile-cust.php" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="text-black" for="email">Email</label>
                  <input type="text" class="form-control" id="email" name="email" value="<?php echo $email;?>" readonly>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">Name</label>
                  <input type="text" class="form-control" id="email" name="name" value="<?php echo $name;?>" required>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">No. Phone</label>
                  <input type="text" class="form-control" id="email" name="nohp" value="<?php echo $nohp;?>" required>
                </div><br>

                <?php
		              }
		            }

				        ?>

                <br>

                <button type="submit" name="submit-test" class="btn btn-primary-hover-outline">Update Profile</button> &nbsp;&nbsp;<a href="change-pass-cust.php" class="btn btn-secondary me-2">Change Password</a>
              </form>


		      	</div><br>
		    </div>
		</div>



		<!-- Start Footer Section -->
			<?php include("footer-cust.php"); ?>
		<!-- End Footer Section -->	

		

		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
