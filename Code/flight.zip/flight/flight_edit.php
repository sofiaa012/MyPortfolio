<?php
//Sambungan ke DB
include ('db_conn.php');

//dapatkan idrumah
$id = $_GET["id"];

###### jika user kLik button KEMASKINI,
######      update record dalam jaduaL     ##############
if(isset($_POST['edit']))
{
    //jika user ubah gambar, update data2 termasuk gambar
    if (!empty($_FILES['picture']['name']))
	{
        $picture = ('images/'.$_FILES['picture']['name']); //path gambar
		
		//pastikan jenis fiLe gambar yg di upload
        if (preg_match("!image!", $_FILES['picture']['type']))
		{
            //masukkan gambar daLam foLder images
            copy($_FILES['picture']['tmp_name'], $gambar);
			
			$sql = "UPDATE flight
                    SET flightname = '".$_POST["flightname"]."',
                        price = '".$_POST["price"]."',
                        nounit = '".$_POST["unit"]."',
                        picture = '$picture'
                    WHERE flightid = '$id'";

            if (mysqli_query($conn, $sql))
			{
             echo '<script>alert("Flight Update Successful!");
                   window.location.href="flight_list.php";</script>';
            } else {
                echo "Error ; " . mysqli_error($conn); }
        } else {
            echo '<script>alert("Please select GIF/JPG/PNG images only!");
              window.location.href="flight_edit.php?id='.$id.'";</script>';
		}
	} else {
    //jika user tak ubah gambar, update data2 Lain
    $sql = "UPDATE flight
            SET flightname = '".$_POST["flightname"]."',
                price = '".$_POST["price"]."',
                nounit = '".$_POST["unit" ]."'
            WHERE flightid = '$id'";
			
	if (mysqli_query($conn, $sql)) {
	        echo '<script>alert("flight Update Successful!");
               window.location.href="flight_list.php";</script>';
	} else {
	    echo "Error ; " . mysqli_error($conn); }
		
	}
}
########## PROSES UPDATE TAMAT #################################

//dapatkan data rumah dari jaduaL untuk dispLay dalam textfieLd 
$query = "SELECT * FROM flight 
          WHERE flightid = '$id'";
		  
$result = mysqli_query($conn, $query) or die(mysql_error());
$row1 = mysqli_fetch_array($result);

?>

<html>
<head>
<style>
#mainbody
{
  background-color: white;
  padding: 20px;
  margin-left: 20%;
  margin-top: 5%;
}
#tajuk
{
	font-size: 30px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
}
table {
	border: 2px solid black;
    border-collapse: collapse;
    margin: auto;
    background-color: skyblue;
}
#label {
    text-align: right;
}
</style>
</head>

<body>
<?php
include 'sidebar.php';
//include ("header.php");
//include ("topnav2.php");
?>
<div id="mainbody">
<form action="" method="POST" enctype"multipart/form-data">
    <div id="tajuk"><p>Flight Information Update Form</p></div>
<table cellpadding=5px>
<tr>
    <td style="width: 20px"></td>
    <td></td>
    <td></td>
    <td style="width: 20px"></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td></td>
	<td id="label">Flight ID :</td>
    <td><input type="text" name="flightid" size="35"
               value="<?php echo $row1['flightid']; ?>" disabled></td>
    <td></td>
</tr>
<tr>
	<td></td>
	<td id="label">Flight Name :</td>
    <td><input type="text" name="flightname" size="35"
               value="<?php echo $row1['flightname']; ?>" required></td>
    <td></td>
</tr>
<tr>
    <td></td>
	<td id="label">Price :</td>
	<td><input type="number" name="price" step="any"
	           value="<?php echo $row1['price']; ?>" required></td>
    <td></td>
</tr>
<tr>
    <td></td>
	<td id="label">Seat :</td>
	<td><input type="number" name="unit"
	           value="<?php echo $row1['nounit']; ?>" required></td>
	<td></td>
</tr>
<tr>
    <td></td>	
	<td id="label">Picture :</td>
	<td align="right"><input type="file" name="picture"
	                         accept="images/*"></td>
	<td></td>
</tr>
<tr>
	<td></td>
	<td></td>    
	<td id="label"><input type="submit" name="edit" value="EDIT"></td>
	<td></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
</table>

</form>
</div>
<?php
//include ("footer.php");
?>
</body>
</html>