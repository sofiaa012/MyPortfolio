<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>

<style type="text/css">
#mainbody
{
  background-color: white;
  padding: 20px;
  margin-left: 20%;
  margin-top: 5%;
}
#tajuk
{
    font-size: 30px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
    color: black;
}
table {
    border: 2px solid black;
    border-collapse: collapse;
    margin: auto;
    background-color: #4e73df;
}
#label {
    text-align: right;
    color: black;
}
</style>
<body>
<?php
    include 'sidebar.php';
?>

<div id="mainbody">
<form name="daf" action="flight_process.php" method="POST"
    enctype="multipart/form-data">
    <div id="tajuk"><p><center>Flight Registration Form</p></div>
<table cellpadding=5px>
<tr>
    <td style="width: 20px"></td>
    <td></td>
    <td></td>
    <td style="width: 20px"></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td id="label">Flight ID :</td>
    <td><input type="text" name="flightid" size="35"
               placeholder="F00" required></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td id="label">Flight Name :</td>
    <td><input type="text" name="flightname" size="35" required></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td id="label">Ticket Price :</td>
    <td><input type="number" name="price" step="any" placeholder="100"
               required></td>
     <td></td>
</tr>
<tr>
     <td></td>
     <td id="label">Seat :</td>
     <td><input type="number" name="unit" required></td>
     <td></td>
</tr>
<tr>
     <td></td>
     <td id="label">Flight Picture :</td>
     <td align="right" style="color: black;"><input type="file" name="picture" accept="images/*"
                              required></td>
     <td></td>
</tr>
<tr>
     <td></td>
     <td></td>
     <td id="label"><input type="submit" name="register" value="REGISTER"></td>
     <td></td>
</tr>
<tr>
     <td></td>
     <td></td>
     <td></td>
     <td></td>
</tr>
<tr>
     <td></td>
     <td></td>
     <td></td>
     <td></td>
</tr>
</table>
</form>

<!-- borang untuk muatnaik -->
<form name="up" action="flight_process.php" method="POST"
      enctype="multipart/form-data">
    <br>
    <p align="center" style="color: black; margin-left: 10%;">Select a file to upload (Excel .csv file only) :<br>
    <input type="file" name="fail_csv" style="margin-left: 27%;">
    <br>
    <p align="center"><input type="submit" name="upload" value="Upload"></p>
    </p>
</form>

</div>

</div>
</body>
</html>