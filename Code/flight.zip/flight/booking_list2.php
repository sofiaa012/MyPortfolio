<html>
<head>
<style>
#mainbody 
{
  background-color: white;
  padding: 20px;
} 

#tajuk
{
  font-size: 30px;
  font-family: Tw Cen MT Condensed;
  font-weight: bold;
  text-align: center;
  color: black;
}

table {
  border: 1px;
  margin-left: auto;
  margin-right: auto;
  border: 2px solid black;
  border-collapse: collapse;
  margin: auto;
  background-color: whitesmoke;
}

td {
  text-align: center;
  height: 25px;
  color: black;
}

th {
    height: 30px;
    text-align: center; 
    font-weight: bold;
    background-color: #4e73df;
    color: black;
}

</style>
</head>

<body>
<?php
session_start(); 
include 'db_conn.php';
include 'sidebar.php';
//include ("topnav2.php");
?>
<div id="mainbody"> 
    <div id="tajuk"><p><center>Booking List</p></div>

<form action="" method="post"> 
<p><center>
   <select name="category">
        <option>Select</option> 
		<option value="name">Customer Name</option> 
        <option value="flight">Flight Name</option>
        <option value="departing">Depart Date</option>
   </select> 
 : <input type="text" name="search">
<input type="submit" value="Find" name="find">
</p><center>
</form>

<?php 
//jika user klik butang "Cari" dan textbox carian tidak empty
if(isset($_POST['find']) && !empty($_POST['search']) )
{ 
    $search = $_POST['search'];
    //kenalpasti dropdown list apa yang dipilih oleh user
    switch ($_POST["category"]) 
    { 
        case "name": //jika user pilih search by nama pelanggan
        $query = "SELECT * FROM booking INNER JOIN user
                    ON booking.email = user.email
                    INNER JOIN flight
                    ON booking.flightid = flight.flightid					 
		                WHERE user.name LIKE '%$search%'";
    	   break;
        case "flight": //jika user piLih search by jenis rumah
        $query = "SELECT * FROM booking
                  INNER JOIN user
                    ON booking.email = user.email
                  INNER JOIN flight
                    ON booking.flightid = flight.flightid
                  WHERE flight.flightname LIKE '%$search%'";
        break;
        default: //jika user pilih search by tarikhmasuk
        $query = "SELECT * FROM booking
                  INNER JOIN user
                    ON booking.email = user.email
                  INNER JOIN flight
                    ON booking.flightid = flight.flightid
                  WHERE booking.departing = '$search'";
    }
} else {
        //jika user tidak buat carian, papar senarai secara defauLt
        $query = "SELECT * FROM booking
                  INNER JOIN user
                    ON booking.email = user.email
                  INNER JOIN flight
                    ON booking.flightid = flight.flightid";
        }

$mysql = $query;
$result = mysqli_query($conn, $mysql) or die(mysql_error());

if (mysqli_num_rows($result) > 0) {

    //table untuk paparan data
    echo "<table border='1'>";
    echo "<col width='200'>"; //saiz column 1
    echo "<col width='150'>"; //saiz column 2
    echo "<col width='100'>"; //saiz column 3
    echo "<col width='130'>"; //saiz column 4
    echo "<col width='130'>"; //saiz column 5
    echo "<col width='80'>";  //saiz coLumn 6
    echo "<col width='100'>"; //saiz column 7
    echo "<col width='80'>";  //saiz column 8
    echo "<col width='80'>";  //saiz column 9
    echo "<tr>";
    echo "<th>Customer Name</th>";
    echo "<th>Flight Name</th>";
    echo "<th>Flight Price</th>";
    echo "<th>Depart Date</th>";
    echo "<th>Return Date</th>";
    echo "<th>Total Passanger</th>";
    echo "<th>Total Payment</th>";
    echo "<th>Edit</th>";
	echo "<th>Delete</th>";
    echo "</tr>";
	
	//papar semua data dari jaduaL dalam DB
	while($row = mysqli_fetch_assoc($result)) {
	

    //kira jumLah bayaran
    $price = $row['price'];
    $passanger = $row['passanger'];
    $total = $passanger * $price;

        echo "<tr>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['flightname']."</td>";
        echo "<td>RM <span class=\"countPrice\">".$row['price']."</span></td>";
        echo "<td>".$row['departing']."</td>";
        echo "<td>".$row['returning']."</td>";
        echo "<td class=\"countPassanger\">".$row['passanger']."</td>";
        echo "<td>RM <span class=\"countTotal\">".$total."</span></td>";
        echo "<td><a href='booking_edit.php?id=".$row['id']."'>
                  <img src='images/editicon.png' width='30' height='30'>
                  </a></td>";
        echo "<td><a href='booking_delete.php?id=".$row['id']."'>
                  <img src='images/deleteicon.png' width='30' height='30'>
                  </a></td>";
        echo "</tr>";      
	}

  echo "<tr>";
    echo "<td><b>FINAL COUNT</b></td>";
    echo "<td> - </td>";
    echo "<td><b id=\"finalPrice\">PRICE</b></td>";
    echo "<td> - </td>";
    echo "<td> - </td>";
    echo "<td><b id=\"finalPassanger\">PASSANGER</b></td>";
    echo "<td><b id=\"finalTotal\">TOTAL</b></td>";
    echo "<td> - </td>";
    echo "<td> - </td>";
  echo "</tr>";

	echo "</table>";
}
else { echo "<center>No Data</center>"; }
?>
<script>

  var getter = document.querySelectorAll(".countPrice");
  var price = 0;
  for (let i = 0; i < getter.length; i++) {
    price = price + parseInt(getter[i].innerHTML);
  }
  document.getElementById("finalPrice").innerHTML = "RM " + price;

  getter = document.querySelectorAll(".countPassanger");
  var passanger = 0;
  for (let i = 0; i < getter.length; i++) {
    passanger = passanger + parseInt(getter[i].innerHTML);
  }
  document.getElementById("finalPassanger").innerHTML = passanger;

  getter = document.querySelectorAll(".countTotal");
  var total = 0;
  for (let i = 0; i < getter.length; i++) {
    total = total + parseInt(getter[i].innerHTML);
  }
  document.getElementById("finalTotal").innerHTML = "RM " + total;

</script>

</div>
<?php
//include ("footer.php");
?>
</body>
</html>

