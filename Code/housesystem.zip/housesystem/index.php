<?php

require('db_connect.php');


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>WELCOME TO SERI SANTAI COTTAGE</h1>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		<!-- Start Product Section -->
		<div class="product-section">
			<div class="container">
				<div class="row">

					<!-- Start Column 1 -->
					<div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
						<h2 class="mb-4 section-title">Homestay Showcase In Seri Santai</h2>
						<p class="mb-4">Showcase of the finest homestay accommodations </p>
						<p><a href="house-list.php" class="btn">More</a></p>
					</div> 
					<!-- End Column 1 -->

					<?php
            		$query2 = "SELECT * FROM house LIMIT 3";
	              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	              $count = mysqli_num_rows($result);

	                $a =1;

	              if($count>=1)
	              {

	                //fetch data from DB
	                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
	                {
	                    $houseid = $row['houseid'];
	                    $housename = $row['housename'];
	                    $price = $row['price'];
	                    $nounit = $row['nounit'];

	                    $query3 = "SELECT * FROM img_house where houseid ='$houseid'";
				              $result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
				              $count3 = mysqli_num_rows($result3);
            	?>

					<!-- Start Column 2 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="#">
							<?php
									if($count3>=1)
									    {
				              
				              	$row3 = mysqli_fetch_array($result3,MYSQLI_ASSOC);
					                $file_name = $row3['file_name'];
					                $uploaded_on = $row3['uploaded_on'];
							?>
							<img src="uploads/<?php echo $file_name ?>" class="img-fluid product-thumbnail">
							<?php 
												 }else if($count3==0){ ?>

							
							<img src="uploads/none.jpg" class="img-fluid product-thumbnail">

							<?php 		 } ?>
							<h3 class="product-title"><?php echo $housename. " (".$houseid.")";?></h3>


							<strong class="product-price"><?php echo "RM ".$price;?></strong>

						</a>
					</div> 
					<?php

					 			} 
					 		}
					?>
					<!-- End Column 2 -->
					

				</div>
			</div>
		</div>
		<!-- End Product Section -->

		<!-- Start Why Choose Us Section -->
		<div class="why-choose-section">
			<div class="container">
				<div class="row justify-content-between">
					<div class="col-lg-6">
						<h2 class="section-title">Why Choose Us</h2>
						<p>We Provide The Best Homestay In Malaysia</p>

						<div class="row my-5">
							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon" style="align-content: center;">
										<img src="images/like.png" alt="Image" class="imf-fluid" style="width:25px">
									</div>
									<h3>Authentic Local Experience</h3>
									<p>Our homestay offers a genuine experience where you can live like a local and gain insights into the traditions and customs of the area.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon" style="align-content: center;">
										<img src="images/convenient.png" alt="Image" class="imf-fluid" style="width:25px">
									</div>
									<h3>Comfortable and Cozy Accommodations</h3>
									<p>Each room is designed to ensure maximum comfort and relaxation during your stay.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon" style="align-content: center;">
										<img src="images/funding.png" alt="Image" class="imf-fluid" style="width:25px">
									</div>
									<h3>Affordable Luxury</h3>
									<p>Our competitive rates ensure you get the best value for your money without compromising on quality or comfort.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon" style="align-content: center;">
										<img src="images/shield.png" alt="Image" class="imf-fluid" style="width:25px">
									</div>
									<h3>Safety and Security</h3>
									<p>ur homestay is equipped with modern security systems, and we follow strict hygiene and cleanliness protocols to provide a safe and secure environment for our guests.</p>
								</div>
							</div>

						</div>
					</div>

					<div class="col-lg-5">
						<div class="img-wrap">
							<img src="images/homestay1.jpg" alt="Image" class="img-fluid">
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- End Why Choose Us Section -->
		
		<!-- Start Footer Section -->
			<?php include("footer.php"); ?>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
