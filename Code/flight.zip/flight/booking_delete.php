<?php
//session
include('session.php');

//dapatkan id jadual booking
$id = $_GET["id"];

//delete data kereta dalam jadual
$mysql = "DELETE FROM booking
          WHERE id = '$id'";

if (mysqli_query($conn, $mysql)) {
//papar js popup mesej jika maklumat rumah berjaya delete
echo '<script>alert("Booking successfully deleted!");
      window.location.href="booking_list2.php";</script>';
} else {
	echo "Error ; " . mysqli_error($conn);
}
?>