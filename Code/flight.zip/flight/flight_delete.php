<?php
//session
include('session.php');

//dapatkan carid
$id = $_GET["id"];

//deLete data rumah daLam jaduaL
$mysql = "DELETE FROM flight
          WHERE flightid = '$id'";
		  
if (mysqli_query($conn, $mysql))
{
    //papar js popup mesej jika makLumat rumah berjaya deLete
	echo '<script>alert("Flight successfully deleted!");
	        window.location.href="flight_list.php";</script>';
}
else
{
    echo "Error; " . mysqli_error($conn);
}
?>