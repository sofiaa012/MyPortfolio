<?php 
//Sambungan ke DB
include ('db_conn.php');

//dapatkan id tempahan
$id = $_GET["id"];

###### jika user klik button KEMASKINI, ########
###### update record dalam jadual       ########

if(isset($_POST['edit']))
{
    //semak tarikh yang dimasukkan
    //jika tarikhmasuk Lebih besar
    if ($_POST["departing"] > $_POST["returning"])
    {
        echo '<script>
                alert("The entry date is greater than the exit date.
                Please change the date!!");
                window.location.href="booking_edit.php?id='.$id.'";
              </script>';
	}
    //jika tarikhmasuk sama dgn tarikhkeluar
    else if ($_POST["departing"] == $_POST["returning"]) 
    {
        echo '<script>
                alert("The check-in date is the same as the check-out date.
                Please change the date!!");
                window.location.href="booking_edit.php?id='.$id.'";
                </script>';
    }else if ($_POST['passanger'] <= 0)
    {
        echo '<script>
                alert("Passanger cannot be less than 1");
                window.location.href="booking_edit.php?id='.$id.'";
                </script>';
                return;
    }

    $flight = $_POST['flight'];
    $returning = $_POST['returning'];
    $departing = $_POST['departing'];
    $passanger = $_POST['passanger'];

    $sql = "UPDATE `booking` SET `flightid` = '$flight', `departing` = '$departing', `returning` = '$returning', `passanger` = '$passanger' WHERE id = '$id'";
    //$sql = "UPDATE `booking` SET `flightid` = '$flight', `departing` = '$departing', `returning` = '$returning' WHERE `booking`.`id` = '$id'";

            if (mysqli_query($conn, $sql)) {
            echo '<script>alert("Booking Information Update Successful!");
                  window.location.href="booking_list2.php";
                  </script>';
            } else {
                echo "Error ; ". mysqli_error($conn); }
}
########## PROSES UPDATE TAMAT #################################

//dapatkan data tempahan dari jadual untuk display dalam textfield
$query = "SELECT * FROM booking
          INNER JOIN user
            ON booking.email = user.email
          INNER JOIN flight
            ON booking.flightid = flight.flightid
          WHERE booking.id = '$id'";

$result = mysqli_query($conn, $query) or die(mysql_error());
$row1 = mysqli_fetch_array($result);

?>
<html>
<head>
<style>
#mainbody
{
  background-color: white;
  padding: 20px;
  margin-left: 25%;
  margin-top: 5%;
}
#tajuk
{
    font-size: 30px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
    color: black;
}
table {
    border: 2px solid black;
    border-collapse: collapse;
    margin: auto;
    background-color: lightskyblue;
    color: black;
}
table, td {
    text-align: right;
}
</style>
</head>	

<body>
<?php
include ("sidebar.php");
?>
<div id="mainbody">
<form action="" method="POST">
    <div id="tajuk"><p><center>Flight Booking Update Form</p></div>
<table cellpadding=5px>
<tr>
    <td style="width: 20px"></td>
    <td></td>
    <td></td>
    <td style="width: 20px"></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td align="right"></td>
    <td align="left">Customer Name :</td>
    <td><input type="text" name="name"
               value="<?php echo $row1['name']; ?>" disabled>
        </td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>Flight Name :</td>
    <td><select name="flight">
        <option value="<?php echo $row1['flightid']; ?>">
                       <?php echo $row1['flightname']; ?>
        </option>
        <?php
            $mysql = mysqli_query($conn, "SELECT * FROM flight");
            while ($row = mysqli_fetch_array($mysql))
            {
        ?>
        <option value="<?php echo $row['flightid']; ?>">
                       <?php echo $row['flightname']; ?>
        </option>
        <?php } ?>
        </select></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>Departing :</td>
    <td><input type="date" name="departing"
               value="<?php echo $row1['departing']; ?>" required>
        </td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>Returning :</td>
    <td><input type="date" name="returning"
               value="<?php echo $row1['returning']; ?>" required>
        </td>
<td></td>
</tr>
<tr>
    <td></td>
    <td>Passanger :</td>
    <td><input type="unit" name="passanger"
               value="<?php echo $row1['passanger']; ?>" required>
        </td>
<td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td><input type="submit" name="edit" value="EDIT"></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
</tr>
</table>

</form>
</div>

</body>
</html>