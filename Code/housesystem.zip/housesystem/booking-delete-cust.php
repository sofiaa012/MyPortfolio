<?php

session_start();
require('db_connect.php');

$bookingid = $_GET['bookingid'];

// sql to delete a record
$sql3 = "DELETE FROM booking WHERE id='$bookingid'";
if (mysqli_query($connection, $sql3)) {
	echo '<script type ="text/JavaScript">alert("Booking deleted successfully")</script>';
	
} else {
echo "Error deleting record: " . mysqli_error($connection);
}

header("Location: booking-cust.php");


?>