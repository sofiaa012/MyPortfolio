-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2024 at 11:56 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `houseid` varchar(10) NOT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `booked_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `email`, `houseid`, `checkin`, `checkout`, `booked_on`, `total`) VALUES
('B03376', 'aaa@aaa.aaa', 'C03336', '2024-06-27', '2024-06-28', '2024-06-29 03:52:26', '450'),
('B03627', 'aaa@aaa.aaa', 'C03856', '2024-06-24', '2024-06-25', '2024-06-29 03:52:06', '250'),
('B04683', 'bb@bb.bb', 'C06002', '2024-07-24', '2024-07-27', '2024-06-29 09:42:22', '1497'),
('B06855', 'aaa@aaa.aaa', 'C04330', '2024-06-19', '2024-06-21', '2024-06-29 03:51:39', '700'),
('B08067', 'syakira@yahoo.com', 'C03336', '2024-07-24', '2024-07-26', '2024-06-29 09:34:53', '900');

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `houseid` varchar(10) NOT NULL,
  `housename` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `nounit` varchar(5) NOT NULL,
  `emailuser` varchar(50) NOT NULL,
  `uploaded_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`houseid`, `housename`, `price`, `nounit`, `emailuser`, `uploaded_on`) VALUES
('C03336', 'House Angsana', 450, 'V-T-5', 'admin@admin.com', '2024-06-29 03:50:03'),
('C03856', 'House Cempaka', 250, 'V-T-4', 'admin@admin.com', '2024-06-29 03:49:03'),
('C04330', 'House Melur', 350, 'V-T-3', 'admin@admin.com', '2024-06-29 03:50:25'),
('C06002', 'House Tulip', 499, 'T-33-', 'admin@admin.com', '2024-06-29 09:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `img_house`
--

CREATE TABLE `img_house` (
  `id` int(5) NOT NULL,
  `houseid` varchar(10) NOT NULL,
  `file_name` varchar(150) NOT NULL,
  `uploaded_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `img_house`
--

INSERT INTO `img_house` (`id`, `houseid`, `file_name`, `uploaded_on`) VALUES
(70, 'C03856', '2d32a2c741b0393ff8a3b381f26149bb.jpg', '2024-06-29 03:49:03'),
(71, 'C03336', 'blanc-de-blancs-有tepee-heart-img~16a1823d0a827bba_14-5977-1-a3e297a.jpg', '2024-06-29 03:50:03'),
(72, 'C04330', 'tsuda_house_006.jpg', '2024-06-29 03:50:25'),
(75, 'C06002', 'maxresdefault.jpg', '2024-06-29 09:41:53');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `role` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `password`, `name`, `nohp`, `role`) VALUES
('aaa@aaa.aaa', '$2y$10$xYUSUObxalR0WLjBzO.nPOiLHtqRGDyBtcyZdi.PT6ryRK5vvBky2', 'cust1', '0123145698', 2),
('admin@admin.com', '$2y$10$0V/1t/DChtHBatynH15.mOFvobmogdt10/JQjlC5i8WSFvx0WYvEy', 'admin', '012301230123', 1),
('syakira@yahoo.com', '$2y$10$/hUQElo.Gb.1PjvAnzJncOrZQV9dUC6eEUtzRyFkgsBohuK9QbawS', 'SYAKIRA', '999999', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `houseid` (`houseid`) USING BTREE;

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`houseid`);

--
-- Indexes for table `img_house`
--
ALTER TABLE `img_house`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `img_house`
--
ALTER TABLE `img_house`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
