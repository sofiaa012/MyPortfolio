<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home Page Admin</title>
</head>
<style type="text/css">
#tajuk
{
    font-size: 30px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
    color: black;
    margin-left: 30%;
    margin-top: 5%;
}
</style>
<body>
<?php
	include 'sidebar.php';
?>
<p id="tajuk">Welcome to Admin Page</p>
</body>
</html>