<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Register</title>
</head>
<style type="text/css">
#mainbody
{
  background-color: white;
  padding: 20px;
  margin-left: 25%;
  margin-top: 7%;
}
#tajuk
{
    font-size: 35px;
    font-family: Tw Cen MT Condensed;
    font-weight: bold;
    text-align: center;
    color: black;
}    
table {
    border: 2px solid black;
    border-collapse: collapse;
    margin: auto;
    background-color: #4e73df;
}
table, td {
    text-align: right;
    color: black;
}
</style>
<body>
<?php
include 'sidebar.php'
?>
<div id="mainbody">
<form action="user_process.php" method="POST">
    <div id="tajuk"><p><center>Registration New User</div><p>
<table cellpadding=5px>
<tr>
    <td style="width: 30px"></td>
    <td></td>
    <td></td>
    <td style="width: 30px"></td>
</tr>
    <tr>
	<td></td>
    <td></td>
	<td></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>Name :</td>
    <td><input type="text" name="name" required></td>
	<td></td>
</tr>
<tr>
    <td></td>
	<td>Telephone Number :</td>
	<td><input type="text" name="notel" placeholder="0121234567" required></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td>Email :</td>
	<td><input type="email" name="email" placeholder="emel@email.com" required></td>
	<td></td>
</tr>
<tr>
    <td></td>
    <td>Password :</td>
    <td><input type="password" name="password" placeholder="4-8 charaters only"
               pattern=".{4,8}" title="4-8 characters only" required></td>
               <!-- pattern ini untuk setkan had atas dan had bawah -->
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
	<td><input type="submit" name="registrationBtn" value="Register"></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td></td>
    <td></td>
	<td></td>
    <td></td>
</tr>
<tr>
    <td></td>
    <td></td>
	<td></td>
    <td></td>
</tr>
</table>

</form>
</div>
</body>
</html>