<!DOCTYPE html>
<html>
<head>
	<?php include 'db_conn.php';?>
	<title>Flight Booking System</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  	<link href="https://fonts.googleapis.com/css?family=Pacifico|Paytone+One" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="bookingCSS.css">
</head>
<style type="text/css">
	#notis {
    font-size: 12px;
		font-weight: bold;
		color: white;
}

#table {
		margin-left: auto;
		margin-right: auto;
	}

 .table-center {
		margin: 0 auto;
	}

 .team{
            position: relative;
            width: 100%;
            height: 700px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            margin-top: px;
        }
</style>
<?php 
	session_start(); 
	include 'db_conn.php';
?>
<body>

	<!--NavBar-->
	<nav class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">
					<img src="logo.png" id="logo">FH AIRWAYS
				</a>
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expended="false">
					<span class="sr-only"> Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="user_page.php"><strong>Flights</strong></a></li>
					<li class="active"><a href="myBooking.php"><strong>My Booking</strong></a></li>
					<li class=""><a href="flightinformation.php"><strong>Flight Information</strong></a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a><b>Hi, <?php echo $_SESSION['name']; ?></b></a></li>
					<li><a href="index.php"><i class="fa fa-sign-out"><strong>Logout</strong></i></a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!--NavBar End-->

<section class="team">
	<!--Tabs-->
	<div class="container" id="second">
		<!--Tabs Headings-->
		<ul class="nav nav-tabs">		
			<li class="active"><a class="tabshead" data-toggle="tab" href="myBooking.php"><i class="far fa-address-book"></i>Booking List</a></li>
		</ul>
		<!--Tabs Heading End-->

		<!--Tab Content My Bookings-->
      		<div class="tab-content">
      			<h3 class="lab2">My Bookings</h3>
      			<form action="" method="POST"><center>
      				<select name="category" class="drop" required>
      					<option>Select</option>
      					<option value="flight">Flight Name</option>
      					<option value="departing">Departing Date</option>
      				</select>
      				:
      				<input type="text" name="search" class="drop" required >
      				<input type="submit" name="find" value="Find" id="tickButton">
      			</form></center>
      			<center><p style="color: white;">** Any change of date or cancellation,
                 please contact Admin.</p></center>

                <?php
                	$email = $_SESSION['email'];
//jika user kLik butang "Cari" dan textbox carian tidak empty
if(isset($_POST['find']) && !empty($_POST['search']) )
{ 
    //kenaLpasti dropdown list apa yang dipiLih oLeh user
    switch ($_POST["category"]) 
    { 
        case "flight": //jika user piLih search by flight name
        $fname = $_POST['search'];
        // $query = "SELECT * FROM booking
        //           INNER JOIN user
        //             ON booking.email = user.email
        //           INNER JOIN flight
        //             ON booking.flightid = car.flightid				 
		    //       WHERE booking.email = '$email'
				//   AND booking.flightname LIKE '%$fname%'";

        $query = "SELECT * from booking b, flight f WHERE b.flightid = f.flightid AND f.flightname LIKE '%$fname%'";

		break;
		default: //jika user piLih search by departing
        $query = "SELECT * FROM booking
                  INNER JOIN user
                    ON booking.email = user.email
                  INNER JOIN flight
                    ON booking.flightid= flight.flightid			 
		          WHERE booking.email = '$email'
				  AND booking.departing = '$_POST[search]'";			  
    }
} else {
	    //jika user tidak buat carian,papar senarai secara defauLt   
		$query = "SELECT * FROM booking
                  INNER JOIN user
                    ON booking.email = user.email
                  INNER JOIN flight
                    ON booking.flightid = flight.flightid					 
		          WHERE booking.email = '$email'";

	   	} 	  

$mysql = $query;
$result = mysqli_query($conn, $mysql) or die(mysql_error());

if (mysqli_num_rows($result) > 0) {

	//tabLe untuk paparan data

    echo "<table border='1'>";
    echo "<col width='100"; //saiz column
    echo "<col width='150'>"; //saiz column 2
    echo "<col width='100'>"; //saiz column 3
    echo "<col width='130'>"; //saiz column 4
    echo "<col width='130'>"; //saiz column 5
    echo "<col width='90>"; //saiz column 6
    echo "<col width='100'>"; //saiz column 7
    echo "<tr>";  
	   echo "<th>Flight Name</th>";	
     echo "<th>Flight Price</th>";	
     echo "<th>Depart Date</th>";	
     echo "<th>Return Date</th>";	
     echo "<th>Total Time</th>";
     echo "<th>Total Passanger</th>";
	   echo "<th>Total Payment</th>";		   
    echo "</tr>";
 

	//papar semua data dari jaduaL daLam DB
    while($row = mysqli_fetch_assoc($result))
    {
      
		//kira jumLah bayaran
		$price = $row['price'];
    $passanger = $row['passanger'];
		$total = $passanger * $price;
    $returning = strtotime($row['returning']);
    $departing = strtotime($row['departing']);

    $duration = $returning - $departing;
    $duration = date($duration) / 86400; //amount of second per day

    echo "<tr>";
      echo "<td>".$row['flightname']."</td>";
      echo "<td>RM <span class=\"cprice\">".$row['price']."</span></td>";
      echo "<td>".$row['departing']."</td>";
		  echo "<td>".$row['returning']."</td>";
      echo "<td><span class=\"cduration\">". $duration."</span> days</td>";
      echo "<td class=\"cpassanger\">" . $passanger . "</td>";
		  echo "<td>RM <span class=\"ctotal\">".$total."</span></td>";
		echo "</tr>";
	}

		echo "<tr>";
      echo "<td><b>TOTAL</b></td>";
      echo "<td><b id=\"price\">PRICE</b></td>";
      echo "<td></td>";
		  echo "<td></td>";
      echo "<td><b id=\"duration\">DUR</b></td>";
      echo "<td><b id=\"passanger\">PASS</b></td>";
		  echo "<td><b id=\"total\">TOTAL</b></td>";
		echo "</tr>";

    echo "</table>"; 
}
else { echo "<center>No Data</center>"; }
?>
<script type="text/javascript">

	var getter = document.querySelectorAll(".cprice");
  var price = 0;
  for (let i = 0; i < getter.length; i++) {
    price = price + parseInt(getter[i].innerHTML);
  }
  document.getElementById("price").innerHTML = "RM " + price;

  getter = document.querySelectorAll(".cduration");
  var duration = 0;
  for (let i = 0; i < getter.length; i++) {
    duration = duration + parseInt(getter[i].innerHTML);
  }
  document.getElementById("duration").innerHTML = duration + " days";

  getter = document.querySelectorAll(".cpassanger");
  var passanger = 0;
  for (let i = 0; i < getter.length; i++) {
    passanger = passanger + parseInt(getter[i].innerHTML);
  }
  document.getElementById("passanger").innerHTML = passanger;

  getter = document.querySelectorAll(".ctotal");
  var total = 0;
  for (let i = 0; i < getter.length; i++) {
    total = total + parseInt(getter[i].innerHTML);
  }
  document.getElementById("total").innerHTML = "RM " + total;

</script>

      		</div>
      		<!--Tab Content My Bookings Ends-->		
    	</div>
    	<!--Tab Contents End-->
  	</div>
    <!--Tabs End-->
</section>
</body>
</html>