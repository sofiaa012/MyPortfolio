<?php

session_start();
require('db_connect.php');

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-admin.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>User Registered Management</h1>
							</div>
						</div>
						<div class="col-lg-7">
							
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		

		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">

		      		<div class="col-lg-8">
		      			<div class="section-header">
				          <h2>Registration List</h2>
				          <p>Check User Details</p>
				        </div>
				      </div>

				      <div class="col-lg-4">
				      	<div class="input-group">
				          <form action="user-registered-admin.php" method="POST">
				            <input type="search" id="form1" name="search_anything" class="form-control" placeholder="Search....."/>
				            <button type="submit" name="btn-search" class="btn btn-primary" style="margin-top:-75px;left:250px"><i class="fa fa-search"></i></button>
				          </form>
				        </div><br>
				      </div>

				      <div class="row gy-4 gx-lg-5" id="datasearch">
			          <div class="col-lg-12">

			            <table class="table">
			                <tr>
			                  <th scope="col">#</th>
			                  <th scope="col">Name</th>
			                  <th scope="col">Email</th>
			                  <th scope="col">No Phone</th>
			                  <th scope="col">Category</th>
			                  <th scope="col">Action</th>
			                </tr>
			          
			        <?php

			            if (isset($_POST['btn-search'])) //if someone press submit
			            {

			              $search_anything = $_POST['search_anything'];

			              $query = "SELECT * FROM user WHERE email='$search_anything' OR name='$search_anything' OR nohp='$search_anything'";
			              $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
			              $count = mysqli_num_rows($result);

			              if($count>=1)
			              {
			                $a =1;

			                //fetch data from DB
			                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			                {
			                    $name = $row['name'];
			                    $email = $row['email'];
			                    $nohp = $row['title'];
			        ?>
			          
			              <tr>
			                <th scope="row"><?php echo $a; ?></th>
			                <td><?php echo $name; ?></td>
			                <td><?php echo $email; ?></td>
			                <td><?php echo $title; ?></td>
			                <td><?php echo $category; ?></td>
			                <td>
			                  <?php echo "<a href='details-user.php?id-booking=$id'><i class='bi bi-eye'></i></i></a>" ?>
			                  <?php echo "<a href='delete-user.php?id-booking=$id'><i class='bi bi-trash'></i></i></a>&nbsp;&nbsp;" ?>
			                </td>
			              </tr>
			        <?php
			                    $a++;

			                }

			              }

			              else if($count==0)
			              {
			                  echo "<tr><td colspan='6'>Nothing here</td></tr>";
			              }

			            }
			            else
			            { 

			              $query = "SELECT * FROM booking";
			              $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
			              $count = mysqli_num_rows($result);

			                $a =1;

			                //fetch data from DB
			                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			                {
			                    $id = $row['id'];
			                    $name = $row['name'];
			                    $email = $row['email'];
			                    $title = $row['title'];
			                    $category = $row['category'];
			                    $note = $row['note'];
			                    $datetime = $row['registered_date'];
			        ?>
			          
			              <tr>
			                <th scope="row"><?php echo $a; ?></th>
			                <td><?php echo $name; ?></td>
			                <td><?php echo $email; ?></td>
			                <td><?php echo $title; ?></td>
			                <td><?php echo $category; ?></td>
			                <td>
			                  <?php echo "<a href='details-user.php?id-booking=$id'><i class='bi bi-eye'></i></i></a>" ?>
			                  <?php echo "<a href='delete-user.php?id-booking=$id'><i class='bi bi-trash'></i></i></a>&nbsp;&nbsp;" ?>
			                </td>
			              </tr>
			        <?php
			                    $a++;

			                }
			            }

			        ?>

			            </table>
			          </div>
			        </div>


				        

		      		

		      	</div>
		    </div>
		</div>


		<!-- Start Footer Section -->
			<?php include("footer-admin.php"); ?>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
