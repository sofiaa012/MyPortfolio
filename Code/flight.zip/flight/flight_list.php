<html>
<body>
<style>
#mainbody 
{
  background-color: white;
  padding: 20px;
  margin-left: 7%;
} 

#tajuk
{
  font-size: 30px;
  font-family: Tw Cen MT Condensed;
  font-weight: bold;
  text-align: center;
  color: black;
}

table {
  border: 1px;
  margin-left: auto;
  margin-right: auto;
  border: 2px solid black;
  border-collapse: collapse;
  margin: auto;
  background-color: whitesmoke;
}

td {
  text-align: center;
  height: 25px;
  color: black;
}

th {
    height: 30px; _
    text-align: center; 
    font-weight: bold;
    background-color: #4e73df;
    color: black;
}
</style>
</head>

<body>
<?php 
session_start(); 
include 'sidebar.php';
include 'db_conn.php';
//include ("topnav2.php");
?>
<div id="mainbody"> 
    <div id="tajuk"><p><center>List of Flight</p></div>

<form action="" method="post"> 
<p><center>
   <select name="category">
        <option>Select</option> 
        <option value="flight">Flight Name</option>
        <option value="price">Price</option>
   </select> 
 : <input type="text" name="search">
<input type="submit" value="Find" name="find">
</p><center>
</form>

<?php 
//jika user kLik butang "Cari" dan textbox carian tidak empty
if(isset($_POST['find']) && !empty($_POST['search']) )
{ 
    //kenaLpasti dropdown List apa yang dipiLih oleh user
    switch ($_POST["category"]) 
    { 
        case "flight": //jika user piLih search by flightname
        $query = "SELECT * FROM flight
		          WHERE flightname LIKE '%$_POST[search]%'";
		break;
		default: //jika user piLih search by harga
        $query = "SELECT * FROM flight
               	  WHERE price = '$_POST[search]'";
    }
} else {
	    //jika user tidak buat carian,papar senarai secara defauLt   
		$query = "SELECT * FROM flight";
}
$mysql = $query;
$result = mysqli_query($conn, $mysql) or die(mysql_error());

if (mysqli_num_rows($result) > 0)
{
        //tabLe untuk paparan data
    echo "<table border='1'>";
    echo "<col width='80'>";   //saiz coLum 1   
    echo "<col width='150'>";  //saiz coLum 2   
    echo "<col width='200'>";  //saiz coLum 3   
    echo "<col width='100'>";  //saiz coLum 4   
    echo "<col width='80'>";   //saiz coLum 5      
    echo "<col width='150'>";  //saiz coLum 6   
    echo "<col width='80'>";   //saiz coLum 7      
    echo "<tr>";
    echo "<th>Flight ID</th>";
    echo "<th>Flight Name</th>";
    echo "<th>Price</th>";
    echo "<th>Seat</th>";
    echo "<th>Picture</th>";
    echo "<th>Edit</th>";
    echo "<th>Delete</th>";
    echo "</tr>";
    
    //papar semua data dari jaduaL dalam DB
    while($row = mysqli_fetch_assoc($result))
    {
    //dapatkan path gambar
    $img="<img src=".$row['picture'].">";
    
    echo "<tr height='110'>"; 
    echo "<td>".$row['flightid']."</td>";
    echo "<td>".$row['flightname']."</td>";
    echo "<td>RM ".$row['price']."</td>";
    echo "<td>".$row['nounit']."</td>";
    echo "<td><img src=".$row['picture']."
                   width='150' height='100'></td>";
    echo "<td><a href='flight_edit.php?id=".$row['flightid']."'>
              <img src='images/editicon.png' width='40' height='30'>
              </a></td>";
    echo "<td><a href='flight_delete.php?id=".$row['flightid']."'>
              <img src='images/deleteicon.png' width='30' height='30'>
              </a></td>";
    echo "</tr>";
    }
    echo "</table>"; 
	
}
else { echo "<center>No data</center>"; }
?>
</div>
<?php
//include ("footer.php");
?>
</body>
</html>