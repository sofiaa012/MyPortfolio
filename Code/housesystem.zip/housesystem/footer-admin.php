<style>
 .footer-section a, .footer-logo{
 	color:#F3ECDC;
 }
</style>
		<!-- Start Footer Section -->
		<footer class="" style="background:#344E41; color:#F3ECDC">
			<div class="border-top copyright">
					<div class="row pt-12">
						<div class="col-lg-12 text-center" style="margin:0;>
							<center><p class="mb-2 text-center text-lg-start">All rights reserved &copy;2024 - SS Cottege </p></center>
						</div>
		</footer>
		<!-- End Footer Section -->	