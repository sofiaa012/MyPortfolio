<?php
//session
include('session.php');

/*Dapatkan data dari semua medan/textfieLd
  pada borang_tempahan.php*/
//date('Y-m-d', strtotime(str_replace('-', '/', $date)));

$flight = $_POST['flight'];
$departing = date('Y-m-d', strtotime(str_replace('-', '/', $_POST['departing'])));
$returning = date('Y-m-d', strtotime(str_replace('-', '/', $_POST['returning'])));
$passanger = $_POST['passenger'];

// $departing = "'" . $departing . "'";
// $returning = "'" . $returning . "'";
echo $email . '<br>';
echo $flight . '<br>';
echo $departing . '<br>';
echo $returning . '<br>';
echo $passanger . '<br>';

//semak tarikh yang dimasukkan
//jika tarikhmasuk Lebih besar
if ($departing > $returning)
{
    echo '<script>
          alert("The departng date is greater than the returning date. Please change the date!!");
          window.location.href="user_page.php";</script>';
}
//jika tarikhmasuk sama dgn tarikhkeluar
else if ($departing == $returning)
{
   echo '<script>
         alert("The departing date is the same as the returning date. Please change the date!!"); </script>';
}
else if ($passanger <= 0)
{
   echo '<script>
         alert("Passanger cannot be less than 1"); </script>';
}
else
{
   if (isset($_POST['submit']))
   {
        //Simpan data dalam DB
        //$mysql = "INSERT INTO booking (id, email, flightid, departing, returning, passanger) VALUES ('', $email', '$flight', '$departing', '$returning', '$passanger')";
        $mysql = "INSERT INTO `booking` (`id`, `email`, `flightid`, `departing`, `returning`, `passanger`) VALUES ('', '$email', '$flight', '$departing', '$returning', '$passanger')";

        if (mysqli_query($conn, $mysql)) {
            //papar javascript alert jika tempahan bejaya dimasukkan
            echo '<script>
                  alert("Booking successful!");
                  window.location.href="myBooking.php";</script>';
                  //selepas berjaya, redirect ke senarai tempahan
        } else {
            echo "Error ; " . mysqli_error($conn);
        }
    }
}
//CLose connection
mysqli_close($conn);
?>