<?php
//start session
session_start();

//Sambungan ke DB
include ('db_conn.php');

//simpan data session berdasarkan kunci primer daLam jaduaL
$email = $_SESSION['email'];

//dapatkan data pengguna berdasarkan session kunci primer
$mysql = mysqli_query($conn, "SELECT * FROM user WHERE email='$email'");
$row = mysqli_fetch_array($mysql);

$name = $row['name'];
$role = $row['role']; // access LeveL -- 1=admin  2=penggunabiasa

//jika data session tidak dijumpai daLam jaduaL 
if(!isset($email))
{
header("Location: index.php"); //kembaLi ke paparan utama
}

?>
