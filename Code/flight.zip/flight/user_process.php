<?php
//Sambungan ke DB
include ('db_conn.php');

/*Dapatkan data dari semua medan/textfield
  pada borang_penggunabaru.php*/
$name = $_POST['name'];
$notel = $_POST['notel'];
$email = $_POST['email'];
$pwd = md5($_POST['password']); //md5 untuk encrypt pwd

//semak jika emel telah wujud dalam DB
$check = "SELECT email FROM user
          WHERE email = '$email'";
$result = mysqli_query($conn, $check) or die (mysql_error());

//jika emel sudah wujud, keluarkan js popup mesej
if (mysqli_num_rows($result) > 0)
{
    echo '<script>
          alert("Email already in use. Please use another email.");
          window.location.href="admin_register.php";</script>';
} else {
    //jika emel belum wujud, simpan makLumat pengguna dalam DB
    $mysql = "INSERT INTO user
             (email, password, name, nohp, role)
			 VALUES ('$email', '$pwd', '$name', '$notel', 1)";
			 
    if (mysqli_query($conn, $mysql)) {
    //papar js popup mesej jika pengguna baru berjaya daftar
    echo '<script>
	      alert("New User Registration Successful!");
          window.location.href="admin_profile.php";</script>';
		  //selepas berjaya daftar, kembali ke Login page
    } else {
	    echo "Error ; " . mysql_error($conn);
    }
}
//Close connection
mysqli_close($conn);
?>