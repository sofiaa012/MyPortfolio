<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,200&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="AboutCSS.css">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Paytone+One" rel="stylesheet">

    <title>Place to Visit</title>
       <style>

        .team{
            position: relative;
            width: 100%;
            height: 505px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            margin-top: px;
        }

        .team h1{
            width: 100%;
            max-width: 1350px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, auto));
            align-items: center;
            gap: 2rem;
            text-align: center;
           
        }

        .team-content img{
            width: 100%;
            height: auto;
            border-radius: 15px;
            margin-bottom: 15px;
        }

        .center h1{
            color: black;
            font-size: 50px;
            text-align: center;
            margin: 20px;
        }

        .box{
            padding: 16px;
            background: white;
            border-radius: 15px;
            transition: all .38s ease; 
        }

        .box h3{
            font-size: 20px;
            color: black;
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .box h5{
            font-size: 15px;
            font-weight: 600;
            color: black;
            margin-bottom: 10px;
            letter-spacing: 1px;
            white-space: wrap;
        }
        
        .icons i{
            display: inline-block;
            color: black;
            font-size: 20px;
            margin:0 8px;
            transition: all .38s ease;
        }

        .icons i: hover{
            transform: scale(1.3);
        }

        .box:hover{
            transform: translateY(-10px);
            cursor: pointer;
        }
        
        .box img {
            width: 200px; /* Adjust the width as desired */
            height: 200px; /* Adjust the height as desired */
            object-fit: cover; /* Maintain aspect ratio and crop if needed */
            border-radius: 5%; /* Make the image circular */
            margin-bottom: 15px;
        }
         .about-us-container {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 30px;
        }
        
        .about-us-video {
            flex: 1;
            max-width: 50%;
            margin-right: 20px;
        }
        
        .about-us-text {
            flex: 1;
            max-width: 50%;
        }
        
        .about-us-text p {
            margin-top: 0;
        }
</style>
</head>
<body>
<!--NavBar-->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a href="index.php" class="navbar-brand"><img src="logo.png" id="logo"> FH AIRWAYS</a>
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
          </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="index.php"><strong>Home</strong></a></li>
                    <li><a href="About.php"><strong>About Us</strong></a></li>
                    <li class="active"><a href="place.php"><strong>Place to Visit</strong></a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="signup.php"><strong>Sign up </strong><i class="fas fa-user-plus"></i></a></li>
                    <li><a href="login.php" ><strong>Login </strong><i class="fas fa-user"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
  <!--NavBar End-->
    <div class="team">
        <h1 style="color: white;">Best Place to Travel</h1>
    </div>

    <center><video width="640" height="370" controls>
    <source src=    "images/video1.mp4" type="video/mp4">
    Your browser does not support the video tag.
  </video>

</body>
</html>
