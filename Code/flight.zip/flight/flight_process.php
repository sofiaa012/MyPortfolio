<?php
//session
include('session.php');

//jika user klik button Daftar
if (isset($_POST['register']))
{
   //Dapatkan data dari semua textfieLd pada flight_form.php
   $id = $_POST['flightid'];
   $name = $_POST['flightname'];
   $price = $_POST['price'];
   $unit = $_POST['unit'];
   $picture = ('images/'.$_FILES['picture']['name']); //path gambar
   
   //pastikan jenis fiLe gambar yg di upLoad 
   if (preg_match("!image!", $_FILES['picture']['type']))
   {
         //masukkan gambar dalam foLder images
         copy($_FILES['picture']['tmp_name'], $picture);

         //insert data rumah dalam jaduaL
         $mysql = "INSERT INTO flight
                  (flightid, flightname, price, nounit, picture)
                  VALUES
                  ('$id', '$name', '$price', '$unit', '$picture')";
        		 
         if (mysqli_query($conn, $mysql)) { 
             //papar js popup mesej jika makLumat flight berjaya daftar
             echo '<script>
                   alert("Flight Registration Successful!");
                   window.location.href="flight_list.php";</script>';
         } else {
             echo "Error ; " . mysqli_error($conn);  
         } 
    }else{		 
      // echo '<script>
      //       alert("Please select GIF/JPG/PNG images only!");
	// 	    window.location.href="flight_form.php";</script>';
        echo '<script>
            alert("Please select GIF/JPG/PNG images only!");
            </script>';
    }
}
else
{   //jika user klik button Muat Naik
    //dapatkan file .csv tersebut dan simpan dalam temp folder
    $file = $_FILES["fail_csv"]["tmp_name"];
	
    //pastikan (verify) hanya file .csv sahaja yang di upload
    if (($_FILES["fail_csv"]["type"] == "application/vnd.ms-excel"))
    {
     //buka dan baca file tersebut, r = readonly
     $file_open = fopen($file,"r"); 

     //selagi masih ada data dalam fail csv tersebut(EOF),
     //baca line by line
     while(($data = fgetcsv($file_open)) !== FALSE)
     {
      //simpan data ke dalam DB
      $mysql = "INSERT INTO flight
                (flightid, flightname, price, nounit)
                VALUES  
                ('".$data[0]."','".$data[1]."','".$data[2]."',
                 '".$data[3]."')";
				  
      if (mysqli_query($conn, $mysql))
      { 
        echo '<script>alert("The data upload process was successfully executed.");
              window.location.href="flight_list.php";</script>';
      } else { 
           echo "Error: " . $mysql . "<br>" . mysqli_error($conn);   }
     } 
    //tutup file yang dibuka selepas selesai proses import
    fclose($file_open);
    } else {
         //papar popup mesej jika upload file selain .csv
         echo '<script>alert("Please select .CSV file only!!");
               window.location.href="flight_booking.php";</script>'; 
        }	
}
//Close connection
mysqli_close($conn);
?>