<?php
//session
include('session.php');

//dapatkan id jadual booking
$email = $_GET["email"];

//delete data base dalam jadual
$mysql = "DELETE FROM user
          WHERE email = '$email'";

if (mysqli_query($conn, $mysql)) {
//papar js popup mesej jika maklumat rumah berjaya delete
echo '<script>alert("Booking successfully deleted!");
      window.location.href="admin_profile.php";</script>';
} else {
	echo "Error ; " . mysqli_error($conn);
}
?>