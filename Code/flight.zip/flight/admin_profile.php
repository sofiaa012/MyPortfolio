<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Profile</title>
</head>
<style type="text/css">
#mainbody 
{
  background-color: white;
  padding: 20px;
  margin-left: 15%;
  margin-top: 5%;
} 

#tajuk
{
  font-size: 30px;
  font-family: Tw Cen MT Condensed;
  font-weight: bold;
  text-align: center;
  color: black;
}

table {
  border: 1px;
  margin-left: auto;
  margin-right: auto;
  border: 2px solid black;
  border-collapse: collapse;
  margin: auto;
  background-color: whitesmoke;
}

td {
  text-align: center;
  height: 25px;
  color: black;
}

th {
    height: 30px;
    text-align: center; 
    font-weight: bold;
    background-color: #4e73df;
    color: black;
}

</style>
<body>
<?php
  session_start();
  include 'db_conn.php';
  include 'sidebar.php';
?>
<div id="mainbody">
  <div id="tajuk">
    <p align="center">Admin List</p>
  </div>
  <form action="" method="post">
    <p><center>
      <label style="color: black;">Name:</label>
      <input type="text" name="search" required>
      <input type="submit" name="find" value="Find">
    </center></p>
  </form>

<?php
//jika user klik butang "Cari" dan textbox carian tidak empty
if (isset($_POST['find']) && !empty($_POST['search'])) {
  $search = $_POST['search'];
  $query = "SELECT * FROM user WHERE role = 1 AND name LIKE'$search'";
}
else{
  $query = "SELECT * FROM user WHERE role = 1";
}
$mysql = $query;
$result = mysqli_query($conn, $mysql) or die(mysql_error());

if (mysqli_num_rows($result) > 0) {
  //table untuk paparan data
  echo "<table border='1'>";
  echo "<col width='200'>";
  echo "<col width='150'>";
  echo "<col width='150'>";
  echo "<col width='80'>";
  echo "<col width='80'>";
  echo "<tr>";
  echo "<th>Email</th>";
  echo "<th>Name</th>";
  echo "<th>No. Telephone</th>";
  echo "<th>Edit</th>";
  echo "<th>Delete</th>";
  echo "</tr>";

  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>".$row['email']."</td>";
    echo "<td>".$row['name']."</td>";
    echo "<td>".$row['nohp']."</td>";
    echo "<td><a href='admin_edit.php?email=".$row['email']."'>
                  <img src='images/editicon.png' width='30' height='30'>
                  </a></td>";
    echo "<td><a href='admin_delete.php?email=".$row['email']."'>
                  <img src='images/deleteicon.png' width='30' height='30'>
                  </a></td>";
    echo "</tr>"; 
  }
  echo "</table>";
}
else{echo "<center>No Data</center>";}
?>
</div>
</body>
</html>