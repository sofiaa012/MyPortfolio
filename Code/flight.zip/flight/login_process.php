	<?php
//start session
session_start();

//Sambungan ke DB
include ('db_conn.php');

//Dapatkan data dari borang Login
$email = $_POST['email'];
$pwd = md5($_POST['password']); //encrypt pwd yg user masukkan
if (isset($_POST['role'])){
	$role = $_POST['role'];
}

//jika user kLik button Log masuk,
if (isset($_POST['submit']))
{
    //semak emeL dan kata LaLuan daLam jaduaL
    $mysql = "SELECT * FROM user
              WHERE email = '$email' AND password='$pwd'";
    $result = mysqli_query($conn, $mysql);
    $row = mysqli_fetch_array($result);
	
    //jika ADA data emeL dan kata LaLuan yang sama
    if(mysqli_num_rows($result) > 0)
	{
      //dapatkan nama dan kunci primer(emeL) pengguna
	  	$_SESSION['email'] = $row['email']; //simpan data session
	  	$_SESSION['name'] = $row['name'];
      $name = $row['name'];
	
	 //papar popup mesej jika berjaya
      if ($row['role'] == 2) {
      	echo '<script>alert("Welcome '.$name.'");
	      window.location.href="user_page.php";</script>';
      }
      else{
      	echo '<script>alert("Welcome '.$name.'");
	      window.location.href="homepage.php";</script>';
      }
     
    }
	else //jika TIDAK ADA data emeL dan kata LaLuan yang sama
	{
	  echo '<script>alert("WRONG Email or Password!!");
	       window.location.href="login.php";</script>';
		   //kembaLi semuLa ke borang Login
    }
}
//CLose connection db
mysqli_close($conn);
?>