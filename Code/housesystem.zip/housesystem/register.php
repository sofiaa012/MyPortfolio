<?php
  require('db_connect.php');

  if (isset($_POST['submit'])) //if someone press submit
  {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];

    $query = "SELECT * FROM user where email = '$email'";
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
    $count = mysqli_num_rows($result);

    if ($count != 1)
    {
    	if($password == $repassword) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    		$query = "INSERT INTO user (name, email, nohp, password, role) VALUES ('$name','$email','$phone', '$hashed_password', '2')";
    		mysqli_query($connection, $query) or die(mysqli_error($connection));
    		echo '<script type ="text/JavaScript">alert("Register Successfully")</script>';  
	    }
	    else if($password != $repassword) {
	    	echo '<script type ="text/JavaScript">alert("Password is not match !")</script>';  
	    } 
    }
    else if ($count == 1)
    {
    	echo '<script type ="text/JavaScript">alert("This email is existed. Please try again!")</script>'; 
    }



       
  }

?>



<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<?php include("nav.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>BE ONE OF US</h1>
								<p class="mb-4">When you stay with us, you're not just a guest, you become part of our extended family. Enjoy a warm and welcoming atmosphere where connections are made, and lifelong friendships are formed.</p>
								<p><a href="" class="btn btn-secondary me-2">Register</a><a href="login.php" class="btn btn-white-outline">Login</a></p>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		
		<!-- Start Form -->
		<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row justify-content-center">


            <div class="col-md-8 col-lg-8 pb-4">

              <form method="post" action="register.php" class="php-email-form">
                <div class="row">
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="fname">Full name</label>
                      <input type="text" class="form-control" id="fname" name="name" required>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="lname">No. Phone</label>
                      <input type="text" class="form-control" id="lname" name="phone" required>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">Email address</label>
                  <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="row">
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="fname">Password</label>
                      <input type="password" class="form-control" id="fname" name="password" required>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="lname">Re-Password</label>
                      <input type="password" class="form-control" id="lname" name="repassword" required>
                    </div>
                  </div>
                </div>
                <br>

                <button type="submit" name="submit" class="btn btn-primary-hover-outline">Sign me up</button>
              </form>

            </div>

          </div>

        </div>

      </div>


    </div>
  </div>

  <!-- End Contact Form -->

		<?php include("footer.php"); ?>


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
