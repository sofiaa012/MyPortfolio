<?php

session_start();
require('db_connect.php');

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

  $bookingidrefer = rand(1000,10000);
  $emailuser = $_SESSION["email"];

   // File upload directory 
		$targetDir = "uploads/"; 

		if(isset($_POST["submit-test"])){ 

		  $bookingid = $_POST['bookingid'];
		  $email = $_POST['email'];
		  $houseid = $_POST['houseid'];
		  $checkin = $_POST['checkin'];
		  $checkout = $_POST['checkout'];

		  $checkin1 = DateTime::createFromFormat('Y-m-d', $checkin);
		  $checkout1 = DateTime::createFromFormat('Y-m-d', $checkout);
			// $interval = $order_expiry_date->diff($now);
			$interval = $checkin1->diff($checkout1);

			$total = $interval->days;

			$query2 = "SELECT * FROM house where houseid ='$houseid'";
      $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	  	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	      $priceDB = $row['price'];

	    $totalhouse = $total * $priceDB;

		  $query = "INSERT INTO booking (id, email, houseid, checkin, checkout, total) VALUES ('$bookingid','$email','$houseid', '$checkin', '$checkout', '$totalhouse')";
    		mysqli_query($connection, $query) or die(mysqli_error($connection));
    		echo '<script type ="text/JavaScript">alert("Booking Successfully")</script>';  

		 
		} 


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-cust.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<!-- <div class="hero" style="height:60px;">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>hHOUSE BOOKING</h1>
						</div>
					</div>
				</div>
			</div> -->
		<!-- End Hero Section -->

		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">

		      		<div class="col-lg-12">
		      			<div class="section-header">
				          <h2>Booking House</h2>
				          <p>Booking Details</p>
				        </div>
				      </div>

				      <!-- Start Form -->
              <form method="post" action="booking-cust.php" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="text-black" for="fname">Booking ID</label>
                  <input type="text" class="form-control" id="fname" name="bookingid" value="<?php echo "B0".$bookingidrefer;?>" readonly>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">Email</label>
                  <input type="text" class="form-control" id="email" name="email" value="<?php echo $emailuser;?>" readonly>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">House Type</label>
                  <select class="form-control" name="houseid" required>  
                  	<?php
			            		$query2 = "SELECT * FROM house";
				              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
				              $count = mysqli_num_rows($result);
			              	//fetch data from DB
			                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			                {
				                $housename = $row['housename'];
				                $houseid = $row['houseid'];
			            	?>

                    <option value="<?php echo $houseid;?>"><?php echo $housename;?></option>  

                  <?php } ?>

                 </select>   
                </div>
                <div class="row">
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="fname">Check-In</label>
                      <input type="date" class="form-control" id="fname" name="checkin" required>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="lname">Check-Out</label>
                      <input type="date" class="form-control" id="lname" name="checkout" required>
                    </div>
                  </div>
                </div> <br>

                <br>

                <button type="submit" name="submit-test" class="btn btn-primary-hover-outline">Book</button>
              </form>

		      	</div><br><br>

		      	<hr>

		      	<div class="row">
				          <div class="col-lg-12"><br><BR>
										<div class="section-header">
						          <h2>Booking List & Details</h2><br>
						        </div>

				            <table class="table">
				                <tr>
				                  <th scope="col">#</th>
				                  <th scope="col">ID</th>
				                  <th scope="col">Cust Email</th>
				                  <th scope="col">House Type</th>
				                  <th scope="col">Check In</th>
				                  <th scope="col">Check Out</th>
				                  <th scope="col">Total</th>
				                  <th scope="col">Booked on</th>
				                </tr>

				              	<?php
				              		$query2 = "SELECT * FROM booking where email='$emailuser'";
						              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
						              $count = mysqli_num_rows($result);

						                $a =1;

						              if($count>=1)
						              {

						                //fetch data from DB
						                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
						                {
						                    $id = $row['id'];
						                    $email = $row['email'];
						                    $houseid = $row['houseid'];
						                    $checkin = $row['checkin'];
						                    $checkout = $row['checkout'];
						                    $total = $row['total'];
						                    $booked_on = $row['booked_on'];
				              	?>

				              	<script>
									        function confirmDelete() {
									            return confirm("Are you sure you want to delete this record?");
									        }
									    </script>

				                <tr>
					                <th scope="row"><?php echo $a; ?></th>
					                <td><?php echo $id; ?></td>
					                <td><?php echo $email; ?></td>
					                <td><?php echo $houseid; ?></td>
					                <td><?php echo $checkin; ?></td>
					                <td><?php echo $checkout; ?></td>
					                <td><?php echo "RM ".$total; ?></td>
					                <td><?php echo $booked_on; ?></td>
					                <!-- <td>
					                	<?php  //"<a href='booking-update-cust.php?bookingid=$id' ><i class='fa fa-pencil'></i></i></a>&nbsp;&nbsp;" ?>
				                  	<?php //"<a href='booking-delete-cust.php?bookingid=$id' onclick='return confirmDelete();'><i class='fa fa-trash'></i></i></a>&nbsp;&nbsp;" ?>
				                  
				                </td> -->

				                <?php
						                    $a++;

						                }
						              }
						              else if($count==0)
						              {

						            ?>

						            	<td colspan="9">You dont have any house data yet. Book Now!</td>

						            <?php
						              }

								        ?>


				                </tr>

				              </table>
						    </div>
						  </div>

		    </div>
		</div>



		<!-- Start Footer Section -->
			<?php include("footer-cust.php"); ?>
		<!-- End Footer Section -->	

		

		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
