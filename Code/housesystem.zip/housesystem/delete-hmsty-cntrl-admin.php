<?php

session_start();
require('db_connect.php');

$houseid = $_GET['houseid'];

// sql to delete a record
$sql2 = "DELETE FROM house WHERE houseid='$houseid'";
if (mysqli_query($connection, $sql2)) {
	$sql3 = "DELETE FROM img_house WHERE houseid='$houseid'";
	if (mysqli_query($connection, $sql3)) {
		echo '<script type ="text/JavaScript">alert("Record deleted successfully")</script>';
		header("Location: hmsty-cntrl-admin.php");
	}
} else {
  echo "Error deleting record: " . mysqli_error($connection);
}


?>