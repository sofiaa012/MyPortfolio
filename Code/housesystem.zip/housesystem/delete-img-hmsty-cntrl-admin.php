<?php

session_start();
require('db_connect.php');

$houseid = $_GET['houseid'];

// sql to delete a record
$sql3 = "DELETE FROM img_house WHERE houseid='$houseid'";
if (mysqli_query($connection, $sql3)) {
	echo '<script type ="text/JavaScript">alert("Image deleted successfully")</script>';
	header("Location: img-hmsty-admin.php?houseid=$houseid");
} else {
echo "Error deleting record: " . mysqli_error($connection);
}


?>