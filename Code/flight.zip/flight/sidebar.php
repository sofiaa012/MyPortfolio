<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title> FH Airways | Admin Panel</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="adminCSS.css" rel="stylesheet">

<style>
.top-bar {
  background-color: #4e73df;
  color: #fff;
  height: 60px;
  padding: 15px;
  display: flex;
  justify-content: flex-end;
}

.top-bar a {
  color: #fff;
  text-decoration: none;
  font-size:  20px;
  font-weight : bold;
  margin-right: 10px;
}

.top-bar a:hover {
  text-decoration: underline;
}

</style>

</head>

<body id="page-top">
  <!--Top Bar-->
  <div class="top-bar">
    <a href="login.php">Log Out</a>
  </div>

  <!-- Page Wrapper -->
  <div id="wrapper"> 
  <!-- Sidebar -->
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">


<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="homepage.php">
  <div class="sidebar-brand-icon rotate-n-15">
    <i class="fas fa-laugh-wink"></i>
  </div>
  <div class="sidebar-brand-text mx-3">FH <sup>Airways</sup></div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
  <a class="nav-link" href="homepage.php">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>HOME</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  Flight
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
  <a class="nav-link collapsed" href="flight_booking.php">
    <span>Flight Registration Form</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link collapsed" href="flight_list.php">
    <span>Flight List</span>
  </a>
</li>

<li class="nav-item">
  <a class="nav-link collapsed" href="booking_list2.php">
    <span>Booking List</span>
  </a>
</li>

<!--<li class="nav-item">
  <a class="nav-link collapsed" href="booking_list2.php">
    <span>User List</span>
  </a>
</li>-->

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  Admin
</div>

<li class="nav-item">
  <a class="nav-link" href="admin_profile.php">
    <i class="fas fa-fw fa-chart-area"></i>
    <span>Admin Profile</span></a>
</li>

<li class="nav-item">
  <a class="nav-link" href="admin_register.php">
    <i class="fas fa-fw fa-chart-area"></i>
    <span>Admin Register</span></a>
</li>

</ul>
<!-- End of Sidebar -->
