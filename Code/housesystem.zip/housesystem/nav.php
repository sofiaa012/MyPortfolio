<!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

			<div class="container">
				<a class="navbar-brand" href="index.php">H O U S E<span>.</span></a>

				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarsFurni">
					<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
						<li class="nav-item">
							<a class="nav-link" href="index.php">HOME</a>
						</li>
						<li><a class="nav-link" href="house-list.php">HOUSE LIST</a></li>
						<li><a class="nav-link" href="register.php">REGISTER</a></li>
						<li><a class="nav-link" href="contactus.php">CONTACT US</a></li>
					</ul>

					<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5" STYLE="background-color: #F3ECDC;border-radius:50px;">
						<li><a class="nav-link" href="register.php" STYLE="color:#344E41;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GET STARTED</a></li>
					</ul>
				</div>
			</div>
				
		</nav>