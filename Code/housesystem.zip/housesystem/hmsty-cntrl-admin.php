<?php

session_start();
require('db_connect.php');

if (($_SESSION["email"])=='') { header("Location: index.php"); } 

  $houseidrefer = rand(1000,10000);
  $emailuser = $_SESSION["email"];

   // File upload directory 
		$targetDir = "uploads/"; 

		if(isset($_POST["submit-test"])){ 

		  $houseid = $_POST['houseid'];
		  $housename = $_POST['housename'];
		  $price = $_POST['price'];
		  $nounit = $_POST['nounit'];

		  if(!empty($_FILES["file"]["name"])){ 
		      $fileName = basename($_FILES["file"]["name"]); 
		      $targetFilePath = $targetDir . $fileName; 
		      $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION); 
		   
		      // Allow certain file formats 
		      $allowTypes = array('jpg','png','jpeg','gif'); 
		      if(in_array($fileType, $allowTypes)){ 
		          // Upload file to server 
		          if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){ 
		              // Insert image file name into database 
		              $query = "INSERT INTO img_house (file_name, houseid) VALUES ('$fileName','$houseid')";
		              $insert =mysqli_query($connection, $query);
		              if($insert){ 
	              		$query1 = "INSERT INTO house(houseid, housename, price, nounit, emailuser) VALUES ('$houseid','$housename','$price', '$nounit', '$emailuser')";
      mysqli_query($connection, $query1) or die(mysqli_error($connection));
		                  echo '<script type ="text/JavaScript">alert("The house has been uploaded successfully.")</script>'; 
		              }else{ 
		                  echo '<script type ="text/JavaScript">alert("File upload failed, please try again.")</script>'; 
		              }  
		          }else{ 
		              echo '<script type ="text/JavaScript">alert("Sorry, there was an error uploading your file.")</script>'; 
		          } 
		      }else{ 
		        echo '<script type ="text/JavaScript">alert("Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.")</script>'; 
		      } 
		  }else{ 
		      echo '<script type ="text/JavaScript">alert("Please select a file to upload.")</script>';
		  } 
		} 


?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
			<?php include("nav-admin.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero" style="height:60px;">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-12">
							<h1>HOMESTAY REGISTRATION</h1>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		<div class="untree_co-section product-section before-footer-section">
		    <div class="container">
		      	<div class="row">

		      		<div class="col-lg-12">
		      			<div class="section-header">
				          <h2>Registration Homestay</h2>
				          <p>House Details</p>
				        </div>
				      </div>

				      <!-- Start Form -->
              <form method="post" action="hmsty-cntrl-admin.php" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="text-black" for="fname">Homestay ID</label>
                  <input type="text" class="form-control" id="fname" name="houseid" value="<?php echo "C0".$houseidrefer;?>" readonly>
                </div>
                <div class="form-group">
                  <label class="text-black" for="email">Name House</label>
                  <input type="text" class="form-control" id="email" name="housename" required>
                </div>
                <div class="row">
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="fname">Price Per Night (RM)</label>
                      <input type="text" class="form-control" id="fname" name="price" required>
                    </div>
                  </div>
                  <div class="col-6">
                    <div class="form-group">
                      <label class="text-black" for="lname">No-Unit</label>
                      <input type="text" class="form-control" id="lname" name="nounit" required>
                    </div>
                  </div>
                </div> <br>

              	<div class="form-group">
              		<label class="text-black" for="lname">Upload House Image</label>
              		<input id="formFileLg" name="file" type="file" class="btn btn-primary" accept="image/*" required/>
              	</div>

                <br>

                <button type="submit" name="submit-test" class="btn btn-primary-hover-outline">Register</button>
              </form>

		      	</div><br><br>

		      	<hr>

		      	<div class="row">
				          <div class="col-lg-12"><br><BR>
										<div class="section-header">
						          <h2>Homestay List & Details</h2><br>
						        </div>

				            <table class="table">
				                <tr>
				                  <th scope="col">#</th>
				                  <th scope="col">ID</th>
				                  <th scope="col">House Name</th>
				                  <th scope="col">Price</th>
				                  <th scope="col">No Unit</th>
				                  <th scope="col">Picture</th>
				                  <th scope="col">Uploaded on</th>
				                  <th scope="col">Action</th>
				                </tr>

				              	<?php
				              		$query2 = "SELECT * FROM house";
						              $result = mysqli_query($connection, $query2) or die(mysqli_error($connection));
						              $count = mysqli_num_rows($result);

						                $a =1;

						              if($count>=1)
						              {

						                //fetch data from DB
						                while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
						                {
						                    $houseid = $row['houseid'];
						                    $housename = $row['housename'];
						                    $nounit = $row['nounit'];
						                    $price = $row['price'];
						                    $uploaded_on = $row['uploaded_on'];
				              	?>

				                <tr>
					                <th scope="row"><?php echo $a; ?></th>
					                <td><?php echo $houseid; ?></td>
					                <td><?php echo $housename; ?></td>
					                <td><?php echo "RM ".$price; ?></td>
					                <td><?php echo $nounit; ?></td>
					                <td><?php echo "<a href='img-hmsty-admin.php?houseid=$houseid'>View here</i></i></a>&nbsp;&nbsp;" ?></td>
					                <td><?php echo $uploaded_on; ?></td>
					                <td>
				                  <?php echo "<a href='delete-hmsty-cntrl-admin.php?houseid=$houseid'><i class='fa fa-trash'></i></i></a>&nbsp;&nbsp;" ?>
				                </td>

				                <?php
						                    $a++;

						                }
						              }
						              else if($count==0)
						              {

						            ?>

						            	<td colspan="8">No Homestay Register Yet</td>

						            <?php
						              }

								        ?>


				                </tr>

				              </table>
						    </div>
						  </div>

		    </div>
		</div>



		<!-- Start Footer Section -->
			<?php include("footer-admin.php"); ?>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
