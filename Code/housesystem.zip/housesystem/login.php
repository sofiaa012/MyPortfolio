<?php
  require('db_connect.php');
  session_start(); 

  if (isset($_POST['submit'])) //if someone press submit
  {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM user where email = '$email'";
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
    $count = mysqli_num_rows($result);

    //fetch data from DB
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $passDB = $row['password'];
        $emailDB = $row['email'];
        $roleDB = $row['role'];

    if ($count == 1)
    {

      // verify password here with hash
      if(password_verify($password, $passDB))
      {
        if($roleDB == 1){
          $_SESSION['email'] = $emailDB;
          header("Location: index-admin.php");
        }
        else if($roleDB == 2){
          $_SESSION['email'] = $emailDB;
          header("Location: index-cust.php");
        }
        
      }
    }
    else
    {
      echo '<script type ="text/JavaScript">alert("Check your input!")</script>';  
    }

  }

?>



<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="favicon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>HOUSE HOMESTAY SYSTEM</title>
	</head>

	<body>

		<?php include("nav.php"); ?>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>BE ONE OF US</h1>
								<p class="mb-4">When you stay with us, you're not just a guest, you become part of our extended family. Enjoy a warm and welcoming atmosphere where connections are made, and lifelong friendships are formed.</p>
								<p><a href="register.php" class="btn btn-white-outline">Register</a>&nbsp;&nbsp;<a href="login.php" class="btn btn-secondary me-2">Login</a></p>
							</div>
						</div>
						<div class="col-lg-7">
							<div class="hero-img-wrap">
								<img src="images/couch.png" class="img-fluid">
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		
		<!-- Start Form -->
		<div class="untree_co-section">
      <div class="container">

        <div class="block">
          <div class="row justify-content-center">


            <div class="col-md-8 col-lg-8 pb-4">

              <form method="post" action="login.php" class="php-email-form">
                
                <div class="form-group">
                  <label class="text-black" for="email">Email address</label>
                  <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                  <label class="text-black" for="fname">Password</label>
                  <input type="password" class="form-control" id="fname" name="password" required>
                </div>
                
                <br>

                <button type="submit" name="submit" class="btn btn-primary-hover-outline">Sign me in</button>
              </form>

            </div>

          </div>

        </div>

      </div>


    </div>
  </div>

  <!-- End Contact Form -->

		<?php include("footer.php"); ?>


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
